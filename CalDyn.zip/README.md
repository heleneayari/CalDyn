# CalDyn
calcium dynamics automatic characterization
